
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost/freelance-platform', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Gig = mongoose.model('Gig', {
  title: String,
  description: String,
  price: Number,
  freelancer: String,
});

app.post('/gigs', async (req, res) => {
  const gig = new Gig(req.body);
  await gig.save();
  res.send(gig);
});

app.get('/gigs', async (req, res) => {
  const gigs = await Gig.find();
  res.send(gigs);
});

app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});
