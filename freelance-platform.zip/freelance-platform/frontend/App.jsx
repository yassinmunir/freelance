
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [gigs, setGigs] = useState([]);
  const [form, setForm] = useState({ title: '', description: '', price: '', freelancer: '' });

  useEffect(() => {
    axios.get('http://localhost:5000/gigs').then((res) => setGigs(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/gigs', form);
    setForm({ title: '', description: '', price: '', freelancer: '' });
    const res = await axios.get('http://localhost:5000/gigs');
    setGigs(res.data);
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Freelance Gigs in Egypt 🇪🇬</h1>

      <form onSubmit={handleSubmit} className="mb-6 space-y-2">
        <input type="text" placeholder="Gig title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="border p-2 w-full" />
        <input type="text" placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="border p-2 w-full" />
        <input type="number" placeholder="Price (EGP)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="border p-2 w-full" />
        <input type="text" placeholder="Freelancer name" value={form.freelancer} onChange={(e) => setForm({ ...form, freelancer: e.target.value })} className="border p-2 w-full" />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2">Add Gig</button>
      </form>

      <div className="space-y-4">
        {gigs.map((gig) => (
          <div key={gig._id} className="border p-4 rounded shadow">
            <h2 className="text-xl font-bold">{gig.title}</h2>
            <p>{gig.description}</p>
            <p><strong>EGP {gig.price}</strong> — by {gig.freelancer}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
